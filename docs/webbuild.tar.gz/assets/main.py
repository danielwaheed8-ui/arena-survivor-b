import asyncio, os, sys, traceback


def _log(msg):
    print("PYBOOT:", msg, flush=True)


async def _run():
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    _log("importing temple_run.game")
    from temple_run.game import amain
    _log("entering amain()")
    await amain()
    _log("amain returned")


async def main():
    try:
        await _run()
    except BaseException:
        tb = traceback.format_exc()
        print("PYBOOT-FATAL:\n" + tb, flush=True)
        try:
            import pygame
            if not pygame.get_init():
                pygame.init()
            surf = pygame.display.get_surface() or pygame.display.set_mode((1280, 720))
            surf.fill((18, 18, 28))
            try:
                if not pygame.font.get_init():
                    pygame.font.init()
                font = pygame.font.Font(None, 24)
            except Exception:
                font = None
            if font:
                y = 16
                for ln in ("FATAL ERROR:\n" + tb).splitlines()[-26:]:
                    surf.blit(font.render(ln[:116], True, (255, 120, 120)), (14, y))
                    y += 26
            pygame.display.flip()
            while True:
                for _ in pygame.event.get():
                    pass
                await asyncio.sleep(0.1)
        except BaseException as e2:
            print("PYBOOT-FATAL-DISPLAY:", repr(e2), flush=True)


if __name__ == "__main__":
    asyncio.run(main())
